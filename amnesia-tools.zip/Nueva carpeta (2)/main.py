import sys
import re
import os
import sys
from dotenv import load_dotenv

# 1. CARGAMOS EL .ENV (El Jefe enciende las luces)
base_dir = os.path.abspath(os.path.dirname(__file__))
ruta_env = os.path.join(base_dir, 'config', '.env')
load_dotenv(ruta_env)

from config.logger import logger
from core.script_engine import ScriptEngine
from api_clients.gemini_client import GeminiClient
from core.seo_engine import SEOEngine
from core.thumbnail_engine import ThumbnailEngine
from core.trends_engine import TrendsEngine
from core.shorts_engine import ShortsEngine
from core.competitor_engine import CompetitorEngine
from core.upload_engine import UploadEngine
from core.voice_recorder import VoiceRecorder
from core.video_engine import VideoEngine
from core.voice_extractor import VoiceExtractor
from core.asset_manager import AssetManager

def modulo_generador_guiones():
    print("\n--- [MÓDULO 1] Generador de Guiones ---")
    tema_input = input("Introduce el tema exacto del vídeo a generar: ").strip()
    
    if not tema_input:
        logger.warning("Entrada vacía. Operación cancelada.")
        return

    try:
        engine = ScriptEngine()
        guion = engine.generar(tema_input)
        
        if guion:
            engine.guardar(guion, tema_input)
        else:
            logger.error("Proceso abortado: No se pudo generar el contenido.")
    except Exception as e:
        logger.critical(f"Fallo a nivel de módulo: {e}")

def modulo_generador_voz():
    print("\n--- [MÓDULO 2] Generador de Voz Pro (XTTSv2) ---")
    
    # 1. Selección de Voz
    carpeta_voces = "voces"
    os.makedirs(carpeta_voces, exist_ok=True)
    voces_disponibles = [os.path.join(carpeta_voces, f) for f in os.listdir(carpeta_voces) if f.endswith(".wav")]
    if os.path.exists("referencia.wav"):
        voces_disponibles.insert(0, "referencia.wav")

    if not voces_disponibles:
        logger.error("No hay voces disponibles. Añade un archivo .wav de referencia.")
        return

    print("\nVoces disponibles:")
    for i, voz in enumerate(voces_disponibles, 1):
        print(f"  {i}. {voz}")
    
    try:
        eleccion_voz = int(input("\n¿Qué voz usas? (número): ")) - 1
        if eleccion_voz < 0 or eleccion_voz >= len(voces_disponibles):
            raise ValueError
        audio_referencia = voces_disponibles[eleccion_voz]
    except ValueError:
        logger.warning("Selección inválida. Cancelando.")
        return

    # 2. Selección de Guion
    carpeta_guiones = "output/guiones"
    if not os.path.exists(carpeta_guiones):
        logger.error("No existe la carpeta de guiones.")
        return
        
    archivos_guion = [f for f in os.listdir(carpeta_guiones) if f.endswith(".txt") and not f.endswith("_emocional.txt")]
    if not archivos_guion:
        logger.error("No hay guiones base disponibles.")
        return

    archivos_ordenados = sorted(archivos_guion, key=lambda f: os.path.getmtime(os.path.join(carpeta_guiones, f)), reverse=True)
    
    print("\nGuiones disponibles (más recientes primero):")
    for i, g in enumerate(archivos_ordenados, 1):
        print(f"  {i}. {g}")

    try:
        eleccion_g = int(input("\n¿Qué guion procesas? (número): ")) - 1
        if eleccion_g < 0 or eleccion_g >= len(archivos_ordenados):
            raise ValueError
        archivo_guion = os.path.join(carpeta_guiones, archivos_ordenados[eleccion_g])
        nombre_base = archivos_ordenados[eleccion_g].replace(".txt", "")
    except ValueError:
        logger.warning("Selección inválida. Cancelando.")
        return

    # 3. Procesamiento (Emociones + Audio)
    try:
        with open(archivo_guion, "r", encoding="utf-8") as f:
            texto_base = f.read().replace("#", "").strip()

        # Análisis con Gemini
        logger.info("Solicitando análisis de marcadores emocionales a Gemini...")
        llm = GeminiClient()
        
        # Un prompt estrictamente técnico, cero charla.
        prompt_emociones = """Eres un procesador de texto para un sistema Text-To-Speech (TTS). Tu única tarea es reformatear el texto para mejorar la expresividad (añadir '...' para misterio, '!' para impacto, comas para ritmo).
        
        REGLAS CRÍTICAS QUE DEBES CUMPLIR O EL SISTEMA FALLARÁ:
        1. NO respondas con saludos, confirmaciones ni texto conversacional (Prohibido decir "Aquí tienes", "Entendido", etc).
        2. ELIMINA cualquier palabra en MAYÚSCULAS que sea un título de sección (ej: GANCHO:, CONTEXTO:, DESARROLLO:).
        3. ELIMINA por completo cualquier texto que esté entre paréntesis () o asteriscos **. Son acotaciones visuales, no deben leerse.
        4. DIVIDE las frases largas. Ninguna frase individual terminada en punto debe superar las 30 palabras. Usa puntos seguidos para separar ideas.
        5. DEVUELVE ÚNICAMENTE EL TEXTO FINAL LISTO PARA LEERSE.
        
        GUION A PROCESAR:
        """ + texto_base
        
        texto_emocional = llm.generate_text(prompt=prompt_emociones, model='gemini-2.5-flash')
        if not texto_emocional:
            logger.warning("Fallo en el análisis emocional. Usando texto base.")
            texto_emocional = texto_base

        # Sanitización extra por código (Regex) por si la IA se despista
        import re
        # Elimina asteriscos sobrantes y múltiples saltos de línea
        texto_emocional = re.sub(r'\*+', '', texto_emocional)
        # Elimina texto entre paréntesis
        texto_emocional = re.sub(r'\(.*?\)', '', texto_emocional)
        texto_emocional = re.sub(r'\n+', '\n', texto_emocional).strip()
        
        texto_emocional = llm.generate_text(prompt=prompt_emociones, model='gemini-2.5-flash')
        if not texto_emocional:
            logger.warning("Fallo en el análisis emocional. Usando texto base.")
            texto_emocional = texto_base

        # Guardamos la versión emocional para debug
        ruta_emocional = archivo_guion.replace(".txt", "_emocional.txt")
        with open(ruta_emocional, "w", encoding="utf-8") as f:
            f.write(texto_emocional)

        # Carga perezosa (Lazy Loading) del motor de audio para no ocupar VRAM si falla lo anterior
        from core.audio_engine import AudioEngine
        audio_engine = AudioEngine()
        
        ruta_salida = f"output/audios/{nombre_base}_pro.wav"
        audio_engine.sintetizar(texto=texto_emocional, ruta_referencia=audio_referencia, ruta_salida=ruta_salida)

    except Exception as e:
        logger.critical(f"Fallo en el pipeline de voz: {e}")

# (Añade esto debajo de tus otras funciones de módulo)

def modulo_generar_seo():
    print("\n--- [MÓDULO 3] Generador de Paquete SEO Contextual ---")
    carpeta_guiones = "output/guiones"
    
    try:
        if not os.path.exists(carpeta_guiones):
            logger.warning("No existe la carpeta de guiones. Genera uno primero.")
            return

        guiones = [f for f in os.listdir(carpeta_guiones) if f.endswith('.txt')]
        if not guiones:
            logger.warning("No hay guiones disponibles en la carpeta.")
            return

        print("Guiones disponibles para análisis:")
        for i, g in enumerate(guiones, 1): 
            print(f"  {i}. {g}")
            
        try:
            eleccion = int(input("\nSelecciona el guion a analizar (número): ")) - 1
            if eleccion < 0 or eleccion >= len(guiones):
                logger.error("Selección fuera de rango.")
                return
        except ValueError:
            logger.error("Entrada inválida. Debes introducir un número.")
            return

        archivo_seleccionado = guiones[eleccion]
        ruta_guion = os.path.join(carpeta_guiones, archivo_seleccionado)
        
        # Limpiamos el nombre para el archivo final (ej: "guion_memoria.txt" -> "memoria")
        nombre_base = archivo_seleccionado.replace("guion_", "").replace(".txt", "")

        # Leemos el archivo físico
        with open(ruta_guion, "r", encoding="utf-8") as f:
            texto_guion = f.read()

        # Instanciamos y ejecutamos el nuevo motor
        from core.seo_engine import SEOEngine
        engine = SEOEngine()
        resultado_seo = engine.generar_desde_guion(texto_guion)
        
        if resultado_seo:
            exito_guardado = engine.guardar(resultado_seo, nombre_base)
            if exito_guardado:
                print(f"\n✅ Paquete SEO de alto rendimiento generado para: {archivo_seleccionado}")
        else:
            print("\n❌ Fallo en la IA al generar el paquete SEO.")

    except Exception as e:
        logger.critical(f"Fallo general en la orquestación del Módulo 3: {e}")

def modulo_generador_miniaturas():
    print("\n--- [MÓDULO 4] Generador de Miniaturas (Hugging Face) ---")
    tema_input = input("Introduce el título o concepto clave del vídeo: ").strip()
    
    if not tema_input:
        logger.warning("Entrada vacía. Operación cancelada.")
        return

    try:
        engine = ThumbnailEngine()
        exito = engine.generar_y_guardar(tema_input)
        
        if exito:
            print("\n✅ ¡Miniatura generada con éxito! Búscala en la carpeta 'output/thumbnails/'")
        else:
            logger.error("Proceso abortado: No se pudo generar la miniatura.")
    except Exception as e:
        logger.critical(f"Fallo a nivel de módulo: {e}")

def modulo_buscador_tendencias():
    print("\n--- [MÓDULO 5] Buscador de Tendencias (Pytrends + Gemini) ---")
    
    CATEGORIAS = {
        "1": {"nombre": "Inteligencia Artificial", "keywords": ["inteligencia artificial", "chatgpt", "gemini ia", "claude ia", "openai"]},
        "2": {"nombre": "Tecnología General",      "keywords": ["tecnología", "gadgets", "smartphone", "ordenador", "software"]},
        "3": {"nombre": "YouTube y Creadores",     "keywords": ["como crecer en youtube", "monetizar youtube", "shorts youtube", "algoritmo youtube", "youtuber"]},
        "4": {"nombre": "Productividad con IA",    "keywords": ["automatización", "ia para trabajar", "herramientas ia gratis", "prompt engineering", "copilot"]},
        "5": {"nombre": "Personalizada",           "keywords": []},
    }
    
    print("\nCategorías disponibles:")
    for key, cat in CATEGORIAS.items():
        print(f"  {key}. {cat['nombre']}")
        
    eleccion = input("\n¿Qué categoría analizas? (número): ").strip()
    
    if eleccion not in CATEGORIAS:
        logger.warning("Opción no válida. Cancelando.")
        return
        
    categoria_elegida = CATEGORIAS[eleccion]
    
    if eleccion == "5":
        entrada = input("Introduce hasta 5 keywords separadas por coma: ").strip()
        if not entrada:
            logger.warning("Keywords vacías. Cancelando.")
            return
        categoria_elegida["keywords"] = [k.strip() for k in entrada.split(",")][:5]

    try:
        engine = TrendsEngine()
        exito = engine.procesar_y_guardar(categoria_elegida)
        
        if not exito:
            logger.error("El pipeline de tendencias no pudo completarse. Revisa los logs.")
    except Exception as e:
        logger.critical(f"Fallo a nivel de módulo: {e}")

def modulo_extractor_shorts():
    print("\n--- [MÓDULO 6] Extractor de Shorts (YouTube API + Gemini) ---")
    url_input = input("Introduce la URL completa del vídeo de YouTube: ").strip()
    
    if not url_input:
        logger.warning("Entrada vacía. Cancelando.")
        return

    try:
        engine = ShortsEngine()
        exito = engine.procesar_video(url_input)
        if not exito:
            logger.error("Proceso abortado. Revisa los logs superiores.")
    except Exception as e:
        logger.critical(f"Fallo a nivel de módulo: {e}")

def modulo_analizador_competencia():
    print("\n--- [MÓDULO 7] Analizador de Competencia (YouTube API + Gemini) ---")
    print("Puedes introducir: URL del canal (ej. youtube.com/@DotCSV) o nombre (ej. Dot CSV)")
    entrada = input("Canal a analizar: ").strip()
    
    if not entrada:
        logger.warning("Entrada vacía. Cancelando.")
        return

    try:
        engine = CompetitorEngine()
        exito = engine.auditar_canal(entrada)
        if not exito:
            logger.error("Proceso abortado. Revisa los logs.")
    except Exception as e:
        logger.critical(f"Fallo a nivel de módulo: {e}")

def modulo_subidor_youtube():
    print("\n--- [MÓDULO 8] Subida Automática a YouTube ---")
    
    # 1. Listar vídeos
    carpeta_videos = "output/videos"
    os.makedirs(carpeta_videos, exist_ok=True)
    videos = [f for f in os.listdir(carpeta_videos) if f.endswith(('.mp4', '.mov', '.mkv'))]
    
    if not videos:
        logger.warning(f"No hay archivos de vídeo en {carpeta_videos}/. Exporta tu vídeo allí primero.")
        return

    print("\nVídeos disponibles para subir:")
    for i, v in enumerate(videos, 1):
        print(f"  {i}. {v}")
        
    try:
        eleccion_v = int(input("\nSelecciona el vídeo (número): ")) - 1
        ruta_video = os.path.join(carpeta_videos, videos[eleccion_v])
    except (ValueError, IndexError):
        logger.error("Selección inválida.")
        return

    # 2. Listar archivos SEO
    carpeta_seo = "output/seo"
    archivos_seo = [f for f in os.listdir(carpeta_seo) if f.endswith('.txt')]
    
    if not archivos_seo:
        logger.warning("No hay archivos SEO generados. Ejecuta el Módulo 3 primero.")
        return

    print("\nMetadatos SEO disponibles:")
    for i, s in enumerate(archivos_seo, 1):
        print(f"  {i}. {s}")
        
    try:
        eleccion_s = int(input("\nSelecciona el paquete SEO (número): ")) - 1
        ruta_seo = os.path.join(carpeta_seo, archivos_seo[eleccion_s])
    except (ValueError, IndexError):
        logger.error("Selección inválida.")
        return

    # 3. Fecha
    print("\n¿Cuándo quieres publicarlo?")
    print("  1. Ahora mismo (Se subirá en Privado para que lo revises)")
    print("  2. Programar fecha futura")
    opcion_fecha = input("Opción: ").strip()
    
    fecha_iso = None
    if opcion_fecha == "2":
        fecha_iso = input("Introduce fecha y hora (Formato exacto: YYYY-MM-DDTHH:MM:SS, ej: 2026-04-20T18:00:00): ").strip()

    # 4. Ejecutar
    try:
        engine = UploadEngine()
        exito = engine.preparar_y_subir(ruta_video, ruta_seo, fecha_iso)
        if exito:
            print("\n✅ Proceso completado. Revisa tu YouTube Studio.")
    except Exception as e:
        logger.critical(f"Fallo a nivel de módulo: {e}")

def modulo_grabar_voz():
    print("\n--- [MÓDULO 9] Grabador de Voz de Referencia ---")
    print("Ejemplos: voz_normal, voz_emocionado, voz_misterioso")
    nombre = input("Nombre para esta voz: ").strip()

    if not nombre:
        logger.warning("Nombre vacío. Cancelando.")
        return

    try:
        recorder = VoiceRecorder()
        recorder.grabar(nombre)
    except Exception as e:
        logger.critical(f"Fallo a nivel de módulo: {e}")

def modulo_productor_video():
    print("\n--- [MÓDULO 10] Productor de Vídeo Automático ---")

    # Selección de audio
    carpeta_audios = "output/audios"
    audios = [f for f in os.listdir(carpeta_audios) if f.endswith(".wav")]

    if not audios:
        logger.warning("No hay audios en output/audios/. Ejecuta el Módulo 2 primero.")
        return

    print("\nAudios disponibles:")
    for i, a in enumerate(audios, 1):
        print(f"  {i}. {a}")

    try:
        eleccion_a = int(input("\nSelecciona el audio (número): ")) - 1
        ruta_audio = os.path.join(carpeta_audios, audios[eleccion_a])
    except (ValueError, IndexError):
        logger.error("Selección inválida.")
        return

    # Selección de guion
    carpeta_guiones = "output/guiones"
    guiones = [f for f in os.listdir(carpeta_guiones)
               if f.endswith(".txt") and not f.endswith("_emocional.txt")]

    if not guiones:
        logger.warning("No hay guiones disponibles.")
        return

    guiones_ordenados = sorted(
        guiones,
        key=lambda f: os.path.getmtime(os.path.join(carpeta_guiones, f)),
        reverse=True
    )

    print("\nGuiones disponibles:")
    for i, g in enumerate(guiones_ordenados, 1):
        print(f"  {i}. {g}")

    try:
        eleccion_g = int(input("\nSelecciona el guion (número): ")) - 1
        ruta_guion = os.path.join(carpeta_guiones, guiones_ordenados[eleccion_g])
    except (ValueError, IndexError):
        logger.error("Selección inválida.")
        return

    tema = input("\nTema del vídeo (para nombrar el archivo): ").strip()
    if not tema:
        tema = "video"

    try:
        engine = VideoEngine()
        exito = engine.producir_video(ruta_audio, ruta_guion, tema)
        if exito:
            print("\n✅ ¡Vídeo producido con éxito! Búscalo en output/videos/")
        else:
            logger.error("No se pudo producir el vídeo.")
    except Exception as e:
        logger.critical(f"Fallo a nivel de módulo: {e}")

def modulo_extractor_voces():
    print("\n--- [UTILIDAD] Extractor de Referencias Vocales ---")
    
    carpeta_entrada = "output/videos_raw"
    os.makedirs(carpeta_entrada, exist_ok=True)
    
    videos = [f for f in os.listdir(carpeta_entrada) if f.endswith(('.mp4', '.mov', '.mkv', '.avi'))]
    
    if not videos:
        logger.warning(f"No hay vídeos en {carpeta_entrada}/. Pon ahí el vídeo del que quieras extraer la voz.")
        return

    print("\nVídeos disponibles para extraer voz:")
    for i, v in enumerate(videos, 1):
        print(f"  {i}. {v}")
        
    try:
        eleccion = int(input("\nSelecciona el vídeo (número): ")) - 1
        archivo_elegido = videos[eleccion]
    except (ValueError, IndexError):
        logger.error("Selección inválida.")
        return

    nombre_salida = input("\nDime el nombre para esta voz (ej. 'narrador_documental', 'chica_joven'): ").strip()
    # Limpiamos el nombre para que no tenga caracteres raros
    nombre_salida = "".join(c if c.isalnum() else "_" for c in nombre_salida).lower()
    
    if not nombre_salida:
        logger.warning("Debes proporcionar un nombre para guardar el archivo.")
        return

    try:
        extractor = VoiceExtractor()
        extractor.extraer_audio_referencia(archivo_elegido, nombre_salida)
    except Exception as e:
        logger.critical(f"Fallo a nivel de módulo: {e}")

def modulo_generador_video():
    print("\n--- [MÓDULO 10] Productor de Vídeo Automático (Cinematográfico) ---")
    
    # 1. Selección de Audio
    carpeta_audios = "output/audios"
    audios = [f for f in os.listdir(carpeta_audios) if f.endswith(('.wav', '.mp3'))] if os.path.exists(carpeta_audios) else []
    
    if not audios:
        print("\n⚠️ ERROR: No hay audios en 'output/audios/'.")
        print("💡 Solución: Ejecuta el Módulo 5 (Sintetizar voz) o el Módulo 2 (Extraer Voz) primero.")
        return

    print("\nAudios disponibles:")
    for i, a in enumerate(audios, 1): print(f"  {i}. {a}")
    
    entrada_a = input("\nSelecciona audio (número, o '0' para volver): ").strip()
    if entrada_a == '0': return
        
    try:
        eleccion_a = int(entrada_a) - 1
        if eleccion_a < 0 or eleccion_a >= len(audios): raise ValueError
        ruta_audio = os.path.join(carpeta_audios, audios[eleccion_a])
    except ValueError:
        print("\n❌ Selección inválida. Debes escribir un número de la lista.")
        return

    # 2. Selección de Guion
    carpeta_guiones = "output/guiones"
    # Filtramos para que no salgan los .txt residuales de emociones
    guiones = [f for f in os.listdir(carpeta_guiones) if f.endswith('.txt') and not f.endswith('_emocional.txt')] if os.path.exists(carpeta_guiones) else []
    
    if not guiones:
        print("\n⚠️ ERROR: No hay guiones base en 'output/guiones/'.")
        print("💡 Solución: Ejecuta el Módulo 3 primero para generar una historia.")
        return

    print("\nGuiones disponibles:")
    for i, g in enumerate(guiones, 1): print(f"  {i}. {g}")
    
    entrada_g = input("\nSelecciona guion (número, o '0' para volver): ").strip()
    if entrada_g == '0': return
        
    try:
        eleccion_g = int(entrada_g) - 1
        if eleccion_g < 0 or eleccion_g >= len(guiones): raise ValueError
        ruta_guion = os.path.join(carpeta_guiones, guiones[eleccion_g])
    except ValueError:
        print("\n❌ Selección inválida.")
        return

    # 3. Tema e Inicio del Motor
    tema = input("\nTema del vídeo (o '0' para volver): ").strip().lower()
    if tema == '0': return
    if not tema:
        print("\n❌ El tema es obligatorio para nombrar el archivo final.")
        return

    try:
        from core.video_engine import VideoEngine
        engine = VideoEngine()
        # Llamamos al motor cinemático que construimos antes
        engine.producir_video(ruta_audio, ruta_guion, tema)
    except Exception as e:
        logger.error(f"Error en la orquestación del vídeo: {e}")
        print(f"\n❌ Ocurrió un error inesperado al lanzar el motor: {e}")

def modulo_piloto_automatico():
    print("\n==========================================================")
    print(" 🤖 [MODO AUTOPILOTO] FÁBRICA DE CONTENIDO EN SERIE ")
    print("==========================================================")
    
    archivo_lote = "lote_temas.txt"
    if not os.path.exists(archivo_lote):
        print(f"\n❌ ERROR: No se encontró el archivo '{archivo_lote}'. Créalo y pon un tema por línea.")
        return
        
    with open(archivo_lote, "r", encoding="utf-8") as f:
        temas = [linea.strip() for linea in f.readlines() if linea.strip()]
        
    if not temas:
        print(f"\n❌ ERROR: El archivo '{archivo_lote}' está vacío.")
        return
        
    print(f"\n📦 Se han detectado {len(temas)} temas en la cola de producción.")
    
    # Pedir la voz base para todo el lote
    carpeta_voces = "voces"
    voces = [f for f in os.listdir(carpeta_voces) if f.endswith(".wav")]
    if os.path.exists("referencia.wav"): voces.insert(0, "referencia.wav")
    
    if not voces:
        print("\n❌ ERROR: No hay voces disponibles para narrar los vídeos. Ve a la Opción 1 o 2.")
        return
        
    print("\n🎙️ Selecciona la voz que narrará TODOS los vídeos de este lote:")
    for i, v in enumerate(voces, 1): print(f"  {i}. {v}")
    
    try:
        eleccion = int(input("\nNúmero de voz (o '0' para cancelar): ")) - 1
        if eleccion == -1: return
        ruta_voz_maestra = voces[eleccion] if voces[eleccion] == "referencia.wav" else os.path.join(carpeta_voces, voces[eleccion])
    except (ValueError, IndexError): return

    print("\n⚠️ ADVERTENCIA: El sistema va a monopolizar tu CPU/GPU. No cierres la terminal.")
    input("Pulsa ENTER para arrancar la producción en cadena...")

    # Carga de motores (Lazy loading para la memoria)
    from core.script_engine import ScriptEngine
    from core.seo_engine import SEOEngine
    from api_clients.gemini_client import GeminiClient
    from core.audio_engine import AudioEngine
    from core.video_engine import VideoEngine
    import re
    
    engine_script = ScriptEngine()
    engine_seo = SEOEngine()
    llm = GeminiClient()
    engine_audio = AudioEngine()
    engine_video = VideoEngine()

    exitos = 0
    fallos = 0

    # EL BUCLE PRINCIPAL
    for i, tema in enumerate(temas, 1):
        print(f"\n" + "="*50)
        print(f" ⚙️ PROCESANDO VÍDEO {i}/{len(temas)}: {tema.upper()}")
        print("="*50)
        
        nombre_base = "".join([c for c in tema if c.isalnum() or c==' ']).rstrip().replace(" ", "_").lower()
        
        try:
            # 1. GUION
            print("\n📝 1/4 Redactando Guion...")
            guion = engine_script.generar(tema)
            if not guion: raise Exception("Fallo al generar el guion.")
            engine_script.guardar(guion, nombre_base)
            ruta_guion = f"output/guiones/guion_{nombre_base}.txt"
            
            # 2. SEO
            print("🎯 2/4 Generando Metadatos SEO...")
            seo = engine_seo.generar_desde_guion(guion)
            if seo: engine_seo.guardar(seo, nombre_base)
            
            # 3. LOCUCIÓN (Emociones + XTTSv2)
            print("🗣️ 3/4 Sintetizando Voz Neuronal...")
            prompt_emociones = "Reformatea para Text-To-Speech (elimina títulos, acotaciones, divide frases largas).\nGUION:\n" + guion.replace("#", "")
            texto_emocional = llm.generate_text(prompt=prompt_emociones, model='gemini-2.5-flash')
            if not texto_emocional: texto_emocional = guion
            texto_emocional = re.sub(r'\*+|\(.*?\)', '', texto_emocional).strip()
            
            ruta_audio = f"output/audios/{nombre_base}_pro.wav"
            engine_audio.sintetizar(texto=texto_emocional, ruta_referencia=ruta_voz_maestra, ruta_salida=ruta_audio)
            
            # 4. VÍDEO (FFmpeg + Pexels)
            print("🎬 4/4 Renderizando Película (FFmpeg)...")
            exito_video = engine_video.producir_video(ruta_audio, ruta_guion, nombre_base)
            
            if exito_video:
                print(f"\n✅ VÍDEO COMPLETADO: {tema}")
                exitos += 1
            else:
                raise Exception("El renderizado de FFmpeg falló.")
                
        except Exception as e:
            logger.error(f"Fallo en el lote al procesar '{tema}': {e}")
            print(f"\n❌ ERROR EN ESTE VÍDEO: {e}. Saltando al siguiente...")
            fallos += 1
            continue # Pasa al siguiente tema sin colapsar el programa
            
    print("\n" + "="*50)
    print(" 🏁 REPORTE DE PRODUCCIÓN EN CADENA ")
    print(f" Vídeos completados: {exitos}")
    print(f" Vídeos fallidos: {fallos}")
    print("="*50)

def modulo_doblador_global():
    print("\n==========================================================")
    print(" 🌍 [MÓDULO 13] EXPANSIÓN GLOBAL: DOBLAJE MULTILINGÜE ")
    print("==========================================================")
    
    carpeta_guiones = "output/guiones"
    if not os.path.exists(carpeta_guiones):
        print("\n❌ ERROR: No existe la carpeta de guiones.")
        return
        
    # Filtramos para no mostrar archivos que ya son traducciones (que empiezan por un prefijo de idioma como en_, pt_, fr_)
    guiones = [f for f in os.listdir(carpeta_guiones) if f.endswith('.txt') and not f.endswith('_emocional.txt') and not f[:3].endswith('_')]
    
    if not guiones:
        print("\n❌ No hay guiones base en español para traducir.")
        return
        
    print("\n📜 Selecciona el guion original en español que quieres internacionalizar:")
    for i, g in enumerate(guiones, 1): print(f"  {i}. {g}")
    
    try:
        eleccion_g = int(input("\nNúmero de guion (o '0' para cancelar): ")) - 1
        if eleccion_g == -1: return
        archivo_seleccionado = guiones[eleccion_g]
        ruta_guion = os.path.join(carpeta_guiones, archivo_seleccionado)
        nombre_base = archivo_seleccionado.replace("guion_", "").replace(".txt", "")
    except (ValueError, IndexError): return

    # --- NUEVO: SELECCIÓN DE IDIOMA ---
    IDIOMAS = {
        "1": {"idioma": "Inglés", "pais": "Estados Unidos", "prefijo": "en"},
        "2": {"idioma": "Portugués", "pais": "Brasil", "prefijo": "pt"},
        "3": {"idioma": "Francés", "pais": "Francia", "prefijo": "fr"},
        "4": {"idioma": "Alemán", "pais": "Alemania", "prefijo": "de"},
        "5": {"idioma": "Italiano", "pais": "Italia", "prefijo": "it"}
    }
    
    print("\n🌐 ¿A qué mercado quieres expandirte?")
    for k, v in IDIOMAS.items():
        print(f"  {k}. {v['idioma']} ({v['pais']})")
        
    entrada_idioma = input("\nSelecciona el idioma (número, o '0'): ").strip()
    if entrada_idioma == '0' or entrada_idioma not in IDIOMAS:
        print("Operación cancelada.")
        return
        
    mercado = IDIOMAS[entrada_idioma]
    
    print(f"\n🚀 Iniciando traducción neuronal al {mercado['idioma'].upper()}...")
    
    try:
        from api_clients.gemini_client import GeminiClient
        from core.seo_engine import SEOEngine
        
        llm = GeminiClient()
        engine_seo = SEOEngine()
        
        with open(ruta_guion, "r", encoding="utf-8") as f:
            texto_espanol = f.read()

        # 1. TRADUCCIÓN DEL GUION (DINÁMICO)
        print(f"🧠 1/2 Gemini: Adaptando referencias culturales para {mercado['pais']}...")
        prompt_traduccion = f"""Eres un YouTuber experto de {mercado['pais']}. Traduce y adapta el siguiente guion del español al {mercado['idioma']}. 
        REGLAS CRÍTICAS:
        1. Suena completamente nativo de {mercado['pais']}, usa su 'slang' o frases hechas de internet si aplica.
        2. Mantén exactamente la misma estructura de párrafos.
        3. No me des confirmaciones, devuelve SOLO el guion en {mercado['idioma']}.
        
        GUION ORIGINAL:
        {texto_espanol}"""
        
        guion_traducido = llm.generate_text(prompt=prompt_traduccion, model='gemini-2.5-pro')
        if not guion_traducido:
            raise Exception("Gemini falló al traducir el guion.")
            
        # Nombramos el archivo con el prefijo elegido (ej: pt_historia_roma)
        nombre_traducido = f"{mercado['prefijo']}_{nombre_base}"
        ruta_guardado_guion = os.path.join(carpeta_guiones, f"guion_{nombre_traducido}.txt")
        
        with open(ruta_guardado_guion, "w", encoding="utf-8") as f:
            f.write(guion_traducido)
            
        # 2. TRADUCCIÓN DEL SEO (DINÁMICO)
        print(f"🎯 2/2 Gemini: Generando SEO en {mercado['idioma']} (Títulos y Tags virales)...")
        # El SEOEngine usará su prompt interno, pero Gemini es suficientemente listo para ver que el input está en otro idioma y responder en el mismo.
        seo_traducido = engine_seo.generar_desde_guion(guion_traducido)
        if seo_traducido:
            engine_seo.guardar(seo_traducido, nombre_traducido)

        print("\n" + "="*50)
        print(f" ✅ ¡INTERNACIONALIZACIÓN A {mercado['idioma'].upper()} COMPLETADA! ")
        print(f" 📂 Guion guardado: guion_{nombre_traducido}.txt")
        print(f" 📂 SEO guardado: seo_{nombre_traducido}.txt")
        print("="*50)
        print(f"💡 Pon '{nombre_traducido}' en tu archivo 'lote_temas.txt' para renderizarlo luego.")
        
    except Exception as e:
        logger.error(f"Fallo en la internacionalización: {e}")
        print(f"\n❌ Error crítico: {e}")

def main():
    while True:
        print("\n==================================================")
        print("   SISTEMA CENTRAL — AmnesIADivers")
        print("==================================================")
        print(" --- FASE 1: PREPARACIÓN DE RECURSOS ---")
        print("  1. Grabar voz de referencia")
        print("  2. Extraer Voz de Referencia")
        print("\n --- FASE 2: CREACIÓN DE CONTENIDO ---")
        print("  3. Generar nuevo guion")
        print("  4. Generar paquete SEO")
        print("  5. Sintetizar voz a partir de guion")
        print("\n --- FASE 3: INVESTIGACIÓN Y RECURSOS ---")
        print("  6. Auditar Canal de Competencia")
        print("  7. Buscar Tendencias e Ideas")
        print("  8. Extraer Clips para Shorts")
        print("  9. Generar miniatura visual (IA)")
        print("\n --- FASE 4: MONTAJE Y DISTRIBUCIÓN ---")
        print(" 10. Producir vídeo automático")
        print(" 11. Subir y Programar en YouTube")
        print(" 12. Piloto Automático (Procesamiento por Lotes)")
        print(" 13. Doblaje Global a Inglés (Traduce Guion y SEO para otro canal)")
        print("  0. Salir")
        print("==================================================")

        opcion = input("\nSelecciona un módulo: ").strip()

        if opcion == '0': sys.exit(0)
        elif opcion == '1': modulo_grabar_voz()
        elif opcion == '2': modulo_extractor_voces()
        elif opcion == '3': modulo_generador_guiones()
        elif opcion == '4': modulo_generar_seo()
        elif opcion == '5': modulo_generador_voz()
        elif opcion == '6': modulo_analizador_competencia()
        elif opcion == '7': modulo_buscador_tendencias()
        elif opcion == '8': modulo_extractor_shorts()
        elif opcion == '9': modulo_generador_miniaturas()
        elif opcion == '10': modulo_generador_video()
        elif opcion == '11': modulo_subidor_youtube()
        elif opcion == '12': modulo_piloto_automatico()
        elif opcion == '13': modulo_doblador_global()
        else: print("\n⚠️ Opción no válida.")

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nCierre forzado. Apagando...")
        sys.exit(0)
    except Exception as e:
        logger.critical(f"Fallo catastrófico en el menú: {e}")