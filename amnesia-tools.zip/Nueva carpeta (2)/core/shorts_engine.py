import os
import re
from config.logger import logger
from api_clients.gemini_client import GeminiClient
from api_clients.youtube_client import YouTubeClient

class ShortsEngine:
    def __init__(self):
        try:
            self.llm = GeminiClient()
            self.yt_client = YouTubeClient()
        except ValueError:
            logger.error("Faltan credenciales para iniciar ShortsEngine.")
            raise

        self.output_dir = "output/shorts"
        self._asegurar_directorios()

    def _asegurar_directorios(self):
        try:
            os.makedirs(self.output_dir, exist_ok=True)
        except OSError as e:
            logger.critical(f"Fallo de I/O al crear el directorio: {e}")
            raise

    def extraer_id_video(self, url: str) -> str | None:
        patrones = [
            r'(?:v=|\/)([0-9A-Za-z_-]{11})',
            r'(?:youtu\.be\/)([0-9A-Za-z_-]{11})',
            r'(?:shorts\/)([0-9A-Za-z_-]{11})'
        ]
        for patron in patrones:
            match = re.search(patron, url)
            if match:
                return match.group(1)
        return None

    def analizar_mejores_momentos(self, transcripcion: str, info_video: dict) -> str | None:
        logger.info("Enviando transcripción a Gemini para curación de Shorts...")

        system_prompt = """Eres un Productor Ejecutivo experto en YouTube Shorts virales.
        Tu misión es analizar una transcripción con marcas de tiempo y extraer los 3 clips más potentes (entre 30 y 60 segundos de duración) que tengan alto potencial de retención y viralidad.
        
        CRITERIOS DE SELECCIÓN:
        1. Momentos de alta tensión, revelaciones impactantes o datos contraintuitivos.
        2. El clip debe tener sentido por sí solo (autónomo).
        
        FORMATO DE RESPUESTA ESTRICTO:
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        SHORT #[número]
        ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
        ⏱️  TIEMPO: [MM:SS] — [MM:SS]
        🎯 POR QUÉ FUNCIONA: [1 frase analítica]
        📝 TEXTO EXACTO: [Copia literal de la transcripción]
        ✏️  TÍTULO SUGERIDO: [Máximo 50 caracteres]
        🔥 GANCHO MEJORADO: [Reescribe la primera frase para hacerla irresistible]
        #️⃣  HASHTAGS: [3 hashtags hiper-relevantes]
        """
        
        prompt_usuario = f"""
        TÍTULO DEL VÍDEO ORIGINAL: {info_video.get('titulo', 'Desconocido')}
        TRANSCRIPCIÓN:
        {transcripcion[:15000]} # Limitamos a los primeros ~15k caracteres por seguridad de contexto
        """

        respuesta = self.llm.generate_text(
            prompt=prompt_usuario,
            system_instruction=system_prompt,
            model='gemini-2.5-flash',
            temperature=0.7
        )
        
        if not respuesta:
            logger.error("El pipeline de generación de Shorts falló.")
        return respuesta

    def procesar_video(self, url: str) -> bool:
        video_id = self.extraer_id_video(url)
        if not video_id:
            logger.warning("La URL proporcionada no contiene un ID de vídeo válido.")
            return False

        logger.info(f"Iniciando flujo de extracción para ID: {video_id}")
        
        info = self.yt_client.obtener_info_video(video_id)
        if not info:
            return False
            
        logger.info(f"Vídeo detectado: '{info['titulo']}' ({info['vistas']} vistas)")

        transcripcion = self.yt_client.obtener_transcripcion(video_id)
        if not transcripcion:
            return False

        resultado = self.analizar_mejores_momentos(transcripcion, info)
        if not resultado:
            return False

        # Guardado en disco
        reporte = f"EXTRACTOR DE SHORTS — {info['titulo']}\n{'='*55}\n\n{resultado}"
        ruta_salida = os.path.join(self.output_dir, f"shorts_{video_id}.txt")
        
        try:
            with open(ruta_salida, "w", encoding="utf-8") as f:
                f.write(reporte)
            print("\n" + "="*55)
            print(resultado)
            print("="*55)
            logger.info(f"Reporte de Shorts guardado en: {ruta_salida}")
            return True
        except IOError as e:
            logger.error(f"Fallo al escribir el archivo de Shorts: {e}")
            return False