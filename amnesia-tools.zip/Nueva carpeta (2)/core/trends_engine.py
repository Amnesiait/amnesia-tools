import os
import time
from datetime import datetime
from pytrends.request import TrendReq
from config.logger import logger
from api_clients.gemini_client import GeminiClient

class TrendsEngine:
    def __init__(self):
        try:
            self.llm = GeminiClient()
        except ValueError:
            logger.error("No se pudo iniciar TrendsEngine por falta de credenciales de Gemini.")
            raise

        self.output_dir = "output/tendencias"
        self._asegurar_directorios()
        
        # Inicialización blindada de Pytrends
        logger.info("Conectando con Google Trends...")
        try:
            self.pytrends = TrendReq(hl='es-ES', tz=60, timeout=(10, 25))
            logger.info("Conexión con Google Trends establecida.")
        except Exception as e:
            logger.critical(f"Fallo crítico al conectar con Google Trends. Posible bloqueo de IP: {e}")
            self.pytrends = None

    def _asegurar_directorios(self):
        try:
            os.makedirs(self.output_dir, exist_ok=True)
        except OSError as e:
            logger.critical(f"Fallo de I/O al crear el directorio de tendencias: {e}")
            raise

    def obtener_tendencias_tiempo_real(self, pais: str = "ES") -> list:
        if not self.pytrends: return []
        logger.info(f"Obteniendo tendencias en tiempo real para: {pais}")
        try:
            # Pytrends usa 'spain' para trending_searches, no 'ES'
            df = self.pytrends.trending_searches(pn='spain' if pais == "ES" else pais)
            return df[0].tolist()[:10]
        except Exception as e:
            logger.warning(f"Google Trends rechazó la petición en tiempo real (posible Error 429): {e}")
            return []

    def analizar_keywords(self, keywords: list) -> list:
        if not self.pytrends or not keywords: return []
        logger.info(f"Analizando métricas de interés para: {keywords}")
        resultados = []

        try:
            self.pytrends.build_payload(keywords[:5], cat=0, timeframe='now 7-d', geo='ES', gprop='')
            time.sleep(1.5) # Pausa táctica para evitar baneos
            df_interes = self.pytrends.interest_over_time()

            if df_interes.empty:
                logger.warning("Sin datos de interés para estas keywords en los últimos 7 días.")
                return []

            for kw in keywords[:5]:
                if kw in df_interes.columns:
                    promedio = int(df_interes[kw].mean())
                    maximo = int(df_interes[kw].max())
                    resultados.append({"keyword": kw, "promedio": promedio, "maximo": maximo})

            resultados.sort(key=lambda x: x["promedio"], reverse=True)
            return resultados
        except Exception as e:
            logger.error(f"Fallo al analizar keywords en Google Trends: {e}")
            return []

    def obtener_keywords_relacionadas(self, keyword: str) -> list:
        if not self.pytrends: return []
        try:
            self.pytrends.build_payload([keyword], timeframe='now 7-d', geo='ES')
            time.sleep(1.5)
            relacionadas = self.pytrends.related_queries()
            
            if keyword in relacionadas and relacionadas[keyword]['rising'] is not None:
                df_rising = relacionadas[keyword]['rising']
                if not df_rising.empty:
                    return df_rising['query'].tolist()[:5]
        except Exception as e:
            logger.warning(f"No se pudieron obtener consultas relacionadas para '{keyword}': {e}")
        return []

    def generar_ideas_gemini(self, tendencias: list, keywords_ascenso: list, categoria: str) -> str:
        logger.info("Cruzando datos de Trends con Gemini para generar ideas de contenido...")
        
        # Inyección dinámica de la fecha actual
        fecha_actual = datetime.now().strftime("%B de %Y")
        
        system_prompt = f"""Eres un estratega de contenido para el canal de YouTube 'AmnesIADivers' (tecnología e IA para España).
        Estamos en {fecha_actual}. Usa el contexto temporal actual en tus propuestas si es relevante.
        
        Genera 5 ideas de vídeos usando este formato estricto:
        🎬 TÍTULO: [título llamativo de 50-60 caracteres]
        🎯 ÁNGULO: [por qué este tema funcionará ahora mismo en España]
        🔥 GANCHO: [primera frase del vídeo]
        📈 POTENCIAL: [Alto / Medio / Bajo] — [razón]
        """
        
        prompt_usuario = f"""
        DATOS REALES DE GOOGLE TRENDS ESPAÑA:
        - CATEGORÍA A EXPLORAR: {categoria}
        - KEYWORDS MÁS BUSCADAS: {', '.join([r['keyword'] for r in tendencias])}
        - KEYWORDS EN ASCENSO (Breakouts): {', '.join(keywords_ascenso)}
        
        Basa cada idea de vídeo estrictamente en estos datos empíricos.
        """
        
        respuesta = self.llm.generate_text(
            prompt=prompt_usuario,
            system_instruction=system_prompt,
            model='gemini-2.5-flash',
            temperature=0.8
        )
        
        if not respuesta:
            logger.error("El pipeline de generación de ideas falló.")
            return ""
            
        return respuesta

    def procesar_y_guardar(self, categoria_dict: dict) -> bool:
        if not self.pytrends:
            logger.error("Abortando proceso: Motor Pytrends inactivo.")
            return False

        reporte = [f"REPORTE DE TENDENCIAS — {categoria_dict['nombre']}", "="*55, ""]

        # 1. Tiempo Real
        trending = self.obtener_tendencias_tiempo_real()
        if trending:
            reporte.extend(["🔥 TOP 10 TENDENCIAS EN TIEMPO REAL (España)", "-"*45])
            reporte.extend([f"  {i+1:02d}. {t}" for i, t in enumerate(trending)])
            reporte.append("")

        # 2. Análisis Keywords
        resultados = self.analizar_keywords(categoria_dict["keywords"])
        if resultados:
            reporte.extend(["📊 INTERÉS DE KEYWORDS — Últimos 7 días (España)", "-"*45])
            for r in resultados:
                barra = "█" * (r["promedio"] // 10)
                reporte.append(f"  {r['keyword']:<30} {barra} {r['promedio']}/100")
            reporte.append("")

        # 3. Ascenso
        relacionadas = []
        if categoria_dict["keywords"]:
            kw_principal = categoria_dict["keywords"][0]
            logger.info(f"Buscando términos en ascenso para '{kw_principal}'...")
            relacionadas = self.obtener_keywords_relacionadas(kw_principal)
            if relacionadas:
                reporte.extend([f"🚀 KEYWORDS EN ASCENSO ('{kw_principal}')", "-"*45])
                reporte.extend([f"  → {r}" for r in relacionadas])
                reporte.append("")

        # 4. Ideas
        ideas = self.generar_ideas_gemini(resultados, relacionadas, categoria_dict["nombre"])
        reporte.extend(["💡 IDEAS DE VÍDEOS — Estrategia Gemini", "-"*45])
        reporte.append(ideas if ideas else "  [Fallo en la generación de ideas]")

        contenido_final = "\n".join(reporte)
        
        # Mostrar en pantalla
        print("\n" + "="*55)
        print(contenido_final)
        print("="*55)

        # Guardar en disco
        fecha_str = datetime.now().strftime("%Y%m%d_%H%M")
        nombre_cat = "".join(c if c.isalnum() else "_" for c in categoria_dict["nombre"])[:20].lower()
        ruta = os.path.join(self.output_dir, f"tendencias_{nombre_cat}_{fecha_str}.txt")
        
        try:
            with open(ruta, "w", encoding="utf-8") as file:
                file.write(contenido_final)
            logger.info(f"Reporte consolidado en disco: {ruta}")
            return True
        except IOError as e:
            logger.error(f"Fallo al escribir el reporte: {e}")
            return False