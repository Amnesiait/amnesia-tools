import os
from pydantic import BaseModel, Field
from config.logger import logger
from api_clients.gemini_client import GeminiClient

# ==========================================
# 1. DEFINICIÓN DEL ESQUEMA ESTRICTO (PYDANTIC)
# ==========================================
class PaqueteSEO(BaseModel):
    titulos: list[str] = Field(
        description="Exactamente 10 opciones de títulos virales de 50-60 caracteres.", 
        min_length=10, max_length=10
    )
    descripcion: str = Field(
        description="Descripción del vídeo de 150-200 palabras optimizada para SEO."
    )
    tags: list[str] = Field(
        description="Exactamente 20 etiquetas individuales (tags) para YouTube.", 
        min_length=20, max_length=20
    )
    hashtags: list[str] = Field(
        description="Exactamente 5 hashtags relacionados (incluyendo el símbolo #).", 
        min_length=5, max_length=5
    )

# ==========================================
# 2. MOTOR SEO
# ==========================================
class SEOEngine:
    def __init__(self):
        try:
            self.llm = GeminiClient()
        except Exception as e:
            logger.error(f"No se pudo iniciar SEOEngine: {e}")
            raise

        self.output_dir = "output/seo"
        self._asegurar_directorios()

    def _asegurar_directorios(self):
        os.makedirs(self.output_dir, exist_ok=True)

    def generar_desde_guion(self, texto_guion: str) -> str | None:
        system_prompt = """Eres un experto en SEO para YouTube especializado en canales de tecnología e IA.
        
        TU MISIÓN:
        Te voy a proporcionar el GUION EXACTO de un vídeo. Debes leerlo, extraer la esencia y devolver los metadatos estructurados.
        Asegúrate de que los títulos sean estilo 'clickbait honesto' y generen alta curiosidad.
        """
        
        logger.info("Analizando guion completo para extraer paquete SEO JSON...")
        prompt_usuario = f"Aquí tienes el guion:\n\n{texto_guion}"
        
        try:
            # Llamamos a Gemini pasándole nuestro molde de Pydantic
            respuesta_json = self.llm.generate_text(
                prompt=prompt_usuario,
                system_instruction=system_prompt,
                model='gemini-2.5-pro',
                temperature=0.7,
                response_schema=PaqueteSEO
            )
            
            if not respuesta_json:
                return None
                
            # Validamos el JSON devuelto y lo convertimos en un objeto manejable
            datos_validados = PaqueteSEO.model_validate_json(respuesta_json)
            
            # Formateamos los datos validados a un texto legible
            texto_final = self._formatear_salida(datos_validados)
            return texto_final
            
        except Exception as e:
            logger.error(f"Fallo en la extracción estructurada de SEO: {e}")
            return None

    def _formatear_salida(self, datos: PaqueteSEO) -> str:
        """Convierte el objeto Pydantic en un texto legible para guardarlo en el archivo .txt"""
        salida = "TÍTULOS:\n"
        for i, titulo in enumerate(datos.titulos, 1):
            salida += f"{i}. {titulo}\n"
            
        salida += f"\nDESCRIPCIÓN OPTIMIZADA:\n{datos.descripcion}\n"
        salida += f"\nTAGS:\n{', '.join(datos.tags)}\n"
        salida += f"\nHASHTAGS:\n{' '.join(datos.hashtags)}\n"
        
        return salida

    def guardar(self, contenido: str, nombre_base: str) -> bool:
        ruta_completa = os.path.join(self.output_dir, f"seo_{nombre_base}.txt")
        try:
            with open(ruta_completa, "w", encoding="utf-8") as file:
                file.write(contenido)
            logger.info(f"SEO consolidado en disco: {ruta_completa}")
            return True
        except IOError as e:
            logger.error(f"Fallo al escribir el archivo SEO: {e}")
            return False