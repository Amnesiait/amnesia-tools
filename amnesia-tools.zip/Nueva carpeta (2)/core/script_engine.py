import os
from config.logger import logger
from api_clients.gemini_client import GeminiClient

class ScriptEngine:
    def __init__(self):
        # Inyección de dependencias interna
        try:
            self.llm = GeminiClient()
        except ValueError:
            logger.error("No se pudo iniciar ScriptEngine por falta de credenciales.")
            raise

        self.output_dir = "output/guiones"
        self._asegurar_directorios()

    def _asegurar_directorios(self):
        try:
            os.makedirs(self.output_dir, exist_ok=True)
        except OSError as e:
            logger.critical(f"Fallo de I/O al crear el directorio de guiones: {e}")
            raise

    def generar(self, tema: str) -> str | None:
        system_prompt = """Eres el guionista principal del canal de YouTube 'AmnesIADivers'.
IDENTIDAD DEL CANAL:
- Temática: tecnología, inteligencia artificial y su impacto en la vida humana
- Tono: conversacional, intrigante, cercano y directo
- Audiencia: hispanohablantes curiosos, 25-45 años, no necesariamente técnicos

REGLAS INAMOVIBLES:
1. NUNCA empieces con 'Hola, bienvenidos a mi canal' ni saludos genéricos
2. El primer párrafo SIEMPRE es un gancho que genera intriga o impacto inmediato
3. Usa la fórmula AIDA: Atención → Interés → Deseo → Acción
4. Duración objetivo: 8 minutos (aproximadamente 1200-1400 palabras)
5. Divide el guion en secciones con títulos en MAYÚSCULAS
6. El lenguaje es español neutro peninsular (usa 'ordenador', 'móvil', 'vosotros'). Evita expresiones latinoamericanas.

ESTRUCTURA OBLIGATORIA:
- GANCHO (30s) -> CONTEXTO (1m) -> DESARROLLO (4m) -> REVELACIÓN (1m) -> CTA (30s)."""

        prompt_usuario = f"Escribe el guion completo para el siguiente tema: {tema}"
        
        contenido = self.llm.generate_text(
            prompt=prompt_usuario,
            system_instruction=system_prompt,
            model='gemini-2.5-pro'
        )
        
        if not contenido:
            logger.error("El pipeline de generación ha devuelto nulo.")
            
        return contenido

    def guardar(self, contenido: str, tema: str) -> bool:
        nombre_limpio = "".join(c if c.isalnum() else "_" for c in tema)[:30].lower()
        ruta_completa = os.path.join(self.output_dir, f"guion_{nombre_limpio}.txt")
        
        try:
            with open(ruta_completa, "w", encoding="utf-8") as file:
                file.write(contenido)
            logger.info(f"Guion consolidado en disco: {ruta_completa}")
            return True
        except IOError as e:
            logger.error(f"Fallo de permisos o disco al escribir el archivo: {e}")
            return False