import os
from moviepy.editor import VideoFileClip
from config.logger import logger

class VoiceExtractor:
    def __init__(self):
        # Usamos la carpeta 'voces' que ya tienes en tu arquitectura
        # para guardar las referencias limpias.
        self.input_dir = "output/videos_raw" # Carpeta para dejar los vídeos de los que queremos extraer
        self.output_dir = "voces"
        self._asegurar_directorios()

    def _asegurar_directorios(self):
        os.makedirs(self.input_dir, exist_ok=True)
        os.makedirs(self.output_dir, exist_ok=True)

    def extraer_audio_referencia(self, archivo_video: str, nombre_salida: str) -> bool:
        """
        Extrae el audio de un vídeo y lo formatea para clonación de voz por IA.
        """
        ruta_video = os.path.join(self.input_dir, archivo_video)
        ruta_salida = os.path.join(self.output_dir, f"{nombre_salida}.wav")

        if not os.path.exists(ruta_video):
            logger.error(f"No se encuentra el vídeo origen: {ruta_video}")
            return False

        if os.path.exists(ruta_salida):
            logger.warning(f"Ya existe una referencia de voz con el nombre '{nombre_salida}.wav'. Se sobreescribirá.")

        clip = None
        try:
            logger.info(f"Analizando vídeo para extracción vocal: {archivo_video}")
            clip = VideoFileClip(ruta_video)

            if clip.audio is None:
                logger.error("El archivo de vídeo no contiene ninguna pista de audio.")
                return False

            logger.info("Pista de audio localizada. Formateando para IA (WAV, 22050Hz)...")
            
            # Exportamos usando PCM 16-bit, el estándar de oro para clonación
            clip.audio.write_audiofile(
                ruta_salida,
                codec='pcm_s16le',
                fps=22050, 
                logger=None # Desactivamos el log de MoviePy para no ensuciar nuestra consola
            )

            logger.info(f"✅ Voz de referencia guardada con éxito en: {ruta_salida}")
            return True

        except Exception as e:
            logger.error(f"Fallo crítico durante la extracción de audio: {e}")
            return False
            
        finally:
            # Liberamos memoria sí o sí
            if clip:
                clip.close()