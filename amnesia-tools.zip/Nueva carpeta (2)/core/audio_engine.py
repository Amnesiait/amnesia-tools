import os
import torch
from config.logger import logger

# --- HACK DE COMPATIBILIDAD AISLADO ---
os.environ["TRANSFORMERS_NO_ADVISORY_WARNINGS"] = "1"
import transformers.utils.versions
transformers.utils.versions.require_version = lambda *args, **kwargs: None
os.environ["COQUI_TOS_AGREED"] = "1"
# -------------------------------------
from TTS.api import TTS

class AudioEngine:
    def __init__(self):
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        logger.info(f"Iniciando motor XTTSv2 en hardware: {self.device.upper()}")
        try:
            self.tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(self.device)
            logger.info("Motor XTTSv2 cargado con éxito en la VRAM/RAM.")
        except Exception as e:
            logger.critical(f"Fallo crítico al cargar el modelo TTS: {e}")
            raise

    def sintetizar(self, texto: str, ruta_referencia: str, ruta_salida: str) -> bool:
        if not os.path.exists(ruta_referencia):
            logger.error(f"Archivo de referencia no encontrado: {ruta_referencia}")
            return False

        try:
            logger.info("Iniciando síntesis de audio (esto puede tardar)...")
            os.makedirs(os.path.dirname(ruta_salida), exist_ok=True)
            
            self.tts.tts_to_file(
                text=texto,
                file_path=ruta_salida,
                speaker_wav=ruta_referencia,
                language="es",
                split_sentences=True,
            )
            logger.info(f"¡Audio consolidado en disco!: {ruta_salida}")
            return True
        except Exception as e:
            logger.error(f"Excepción nativa durante la síntesis TTS: {e}")
            return False