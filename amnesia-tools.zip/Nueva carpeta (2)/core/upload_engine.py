import os
from config.logger import logger
from api_clients.youtube_client import YouTubeClient

class UploadEngine:
    def __init__(self):
        try:
            self.yt_client = YouTubeClient()
        except ValueError:
            logger.error("Faltan credenciales base para iniciar UploadEngine.")
            raise

    def parsear_seo(self, ruta_txt: str) -> dict:
        """Extrae el Título 1, la Descripción y los Tags del archivo SEO."""
        metadatos = {"titulo": "", "descripcion": "", "tags": [], "categoria": "28"}
        
        try:
            with open(ruta_txt, "r", encoding="utf-8") as f:
                contenido = f.read()

            # Extraer Título (El primero de la lista)
            if "TÍTULOS" in contenido:
                lineas = contenido.split("\n")
                for i, linea in enumerate(lineas):
                    if "1." in linea:
                        metadatos["titulo"] = linea.split("1.", 1)[-1].strip()
                        break

            # Extraer Descripción
            if "DESCRIPCIÓN OPTIMIZADA" in contenido:
                partes = contenido.split("DESCRIPCIÓN OPTIMIZADA")
                desc_raw = partes[1].split("═══")[0].strip()
                metadatos["descripcion"] = desc_raw[:5000]

            # Extraer Tags
            if "TAGS" in contenido:
                partes = contenido.split("TAGS")
                tags_raw = partes[1].split("═══")[0].strip().replace("\n", "")
                metadatos["tags"] = [t.strip() for t in tags_raw.split(",") if t.strip()][:500]

            logger.info(f"Metadatos extraídos: '{metadatos['titulo']}'")
        except Exception as e:
            logger.error(f"Fallo al parsear el archivo SEO: {e}")

        return metadatos

    def preparar_y_subir(self, ruta_video: str, ruta_seo: str, fecha_iso: str = None) -> bool:
        # 1. Obtener cliente OAuth
        cliente_oauth = self.yt_client.autenticar_oauth()
        if not cliente_oauth:
            return False

        # 2. Cargar metadatos
        metadatos = self.parsear_seo(ruta_seo)
        if not metadatos["titulo"]:
            logger.error("El archivo SEO no tiene un formato válido o no se encontró el título.")
            return False

        # 3. Construir Body
        estado = "private"
        publish_at = None

        if fecha_iso:
            estado = "private"
            publish_at = fecha_iso + "+02:00"  # Huso horario España
            logger.info(f"El vídeo se programará para: {publish_at}")
        else:
            logger.info("Sin fecha programada. Subiendo como Privado.")

        body = {
            "snippet": {
                "title": metadatos["titulo"][:100],
                "description": metadatos["descripcion"],
                "tags": metadatos["tags"],
                "categoryId": metadatos["categoria"],
                "defaultLanguage": "es",
                "defaultAudioLanguage": "es"
            },
            "status": {
                "privacyStatus": estado,
                "selfDeclaredMadeForKids": False
            }
        }

        if publish_at:
            body["status"]["publishAt"] = publish_at

        # 4. Ejecutar
        video_id = self.yt_client.ejecutar_subida(cliente_oauth, ruta_video, body)
        return bool(video_id)