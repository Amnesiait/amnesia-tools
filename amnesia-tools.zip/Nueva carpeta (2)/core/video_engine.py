import os
import random
import requests
import ffmpeg
from pydantic import BaseModel, Field
from config.logger import logger
from api_clients.gemini_client import GeminiClient

# ==========================================
# 1. ESQUEMAS DE DIRECTOR DE FOTOGRAFÍA (PYDANTIC)
# ==========================================
class Escena(BaseModel):
    keyword: str = Field(description="Una palabra clave genérica EN INGLÉS para buscar el vídeo (ej: hacker, nature, money, office, abstract, space, technology).")
    justificacion: str = Field(description="Por qué esta imagen encaja con este fragmento del guion.")

class GuionVisual(BaseModel):
    escenas: list[Escena] = Field(description="Lista de escenas cronológicas para el B-Roll.")

# ==========================================
# 2. MOTOR DE VÍDEO AVANZADO + PEXELS
# ==========================================
class VideoEngine:
    def __init__(self):
        self.output_dir = "output/videos"
        self.biblioteca_dir = "biblioteca/videos"
        self.fallback_dir = os.path.join(self.biblioteca_dir, "stock_general")
        self._asegurar_directorios()
        
        try:
            self.llm = GeminiClient()
        except Exception as e:
            logger.error(f"Fallo al cargar Gemini en VideoEngine: {e}")

    def _asegurar_directorios(self):
        os.makedirs(self.output_dir, exist_ok=True)
        os.makedirs(self.fallback_dir, exist_ok=True)

    def _obtener_duracion_audio(self, ruta_audio: str) -> float:
        try:
            probe = ffmpeg.probe(ruta_audio)
            return float(probe['format']['duration'])
        except ffmpeg.Error as e:
            logger.error(f"Error ffprobe: {e.stderr.decode('utf8')}")
            raise

    def _obtener_guion_visual(self, texto_guion: str, num_clips: int) -> list[str]:
        """Hace que Gemini actúe como Director de Fotografía, devolviendo tags en INGLÉS."""
        logger.info(f"Solicitando {num_clips} escenas cronológicas a la IA...")
        
        system_prompt = f"""Eres el Director de Fotografía de un canal de YouTube.
        Lee este guion y divídelo mentalmente en {num_clips} partes iguales.
        Para cada parte, extrae UNA palabra clave visual genérica EN INGLÉS que represente la narración.
        DEBES usar inglés (ej: no uses 'coche', usa 'car')."""
        
        try:
            respuesta_json = self.llm.generate_text(
                prompt=texto_guion,
                system_instruction=system_prompt,
                response_schema=GuionVisual
            )
            
            if not respuesta_json: return ["abstract"] * num_clips
                
            datos_validados = GuionVisual.model_validate_json(respuesta_json)
            keywords = [escena.keyword.lower().strip() for escena in datos_validados.escenas]
            
            while len(keywords) < num_clips: keywords.append(keywords[-1] if keywords else "abstract")
            return keywords[:num_clips]
            
        except Exception as e:
            logger.error(f"Fallo en la IA visual: {e}")
            return ["abstract"] * num_clips

    def _descargar_de_pexels(self, keyword: str) -> str | None:
        """Se conecta a la API de Pexels, descarga el mejor clip y lo guarda localmente."""
        api_key = os.getenv("PEXELS_API_KEY")
        if not api_key:
            logger.warning("Falta PEXELS_API_KEY en .env. Imposible autodescargar.")
            return None

        logger.info(f"🌐 Buscando '{keyword}' en internet (Pexels)...")
        url = f"https://api.pexels.com/videos/search?query={keyword}&per_page=15&orientation=landscape"
        headers = {"Authorization": api_key}

        try:
            response = requests.get(url, headers=headers, timeout=10)
            if response.status_code != 200:
                logger.error(f"Pexels rechazó la conexión (Código {response.status_code})")
                return None

            datos = response.json()
            if not datos.get("videos"):
                logger.warning(f"Pexels no encontró nada para '{keyword}'.")
                return None

            video_data = random.choice(datos["videos"])
            video_files = video_data.get("video_files", [])
            # Priorizar formato HD (1080p o 720p)
            hd_file = next((f for f in video_files if f.get("quality") == "hd"), video_files[0] if video_files else None)

            if not hd_file: return None
            download_link = hd_file.get("link")

            logger.info("⬇️ Descargando vídeo desde Pexels. Por favor, espera...")
            vid_response = requests.get(download_link, stream=True, timeout=30)
            if vid_response.status_code == 200:
                carpeta_destino = os.path.join(self.biblioteca_dir, keyword)
                os.makedirs(carpeta_destino, exist_ok=True)
                ruta_final = os.path.join(carpeta_destino, f"pexels_{video_data['id']}.mp4")
                
                with open(ruta_final, 'wb') as f:
                    for chunk in vid_response.iter_content(chunk_size=1024*1024):
                        if chunk: f.write(chunk)
                logger.info(f"✅ Descarga completada: {ruta_final}")
                return ruta_final
                
        except Exception as e:
            logger.error(f"Fallo durante la descarga de Pexels: {e}")
            
        return None

    def _buscar_video(self, keyword: str) -> str:
        """Busca en local. Si no está, lo roba de internet. Si todo falla, usa el comodín."""
        rutas_locales = [
            os.path.join(self.biblioteca_dir, keyword),
            self.biblioteca_dir
        ]
        
        # 1. Búsqueda Local Exacta
        for ruta in rutas_locales:
            if os.path.exists(ruta):
                videos = [f for f in os.listdir(ruta) if f.endswith(('.mp4', '.mov'))]
                if videos: return os.path.join(ruta, random.choice(videos))
                    
        # 2. Rescate de Internet (Pexels)
        ruta_descargada = self._descargar_de_pexels(keyword)
        if ruta_descargada:
            return ruta_descargada
            
        # 3. Plan C: Comodín Local (Stock General)
        if os.path.exists(self.fallback_dir):
            videos_stock = [f for f in os.listdir(self.fallback_dir) if f.endswith(('.mp4', '.mov'))]
            if videos_stock:
                logger.warning(f"Usando clip genérico para '{keyword}'")
                return os.path.join(self.fallback_dir, random.choice(videos_stock))
                
        raise FileNotFoundError(f"Imposible continuar. No hay vídeos locales para '{keyword}', Pexels falló, y no hay vídeos en stock_general.")

    def producir_video(self, ruta_audio: str, ruta_guion: str, tema: str) -> bool:
        logger.info(f"--- INICIANDO PRODUCCIÓN CINEMATOGRÁFICA: {tema} ---")
        
        if not os.path.exists(ruta_audio) or not os.path.exists(ruta_guion):
            logger.error("Faltan archivos base.")
            return False

        try:
            # 1. Tiempos
            duracion_audio = self._obtener_duracion_audio(ruta_audio)
            segundos_por_clip = 6.0
            num_clips = max(1, int(duracion_audio / segundos_por_clip))
            duracion_real_clip = duracion_audio / num_clips
            
            # 2. Guion Visual (Inglés)
            with open(ruta_guion, "r", encoding="utf-8") as f:
                texto_guion = f.read()
            keywords = self._obtener_guion_visual(texto_guion, num_clips)
            logger.info(f"Guion visual: {keywords}")

            # 3. Recolección de Recursos (Disco + Web)
            clips_ffmpeg = []
            for kw in keywords:
                ruta_video = self._buscar_video(kw)
                
                # Normalización estricta para evitar bloqueos
                nodo_video = (
                    ffmpeg.input(ruta_video, stream_loop=-1)
                    .video
                    .filter('scale', 1920, 1080, force_original_aspect_ratio='increase')
                    .filter('crop', 1920, 1080)
                    .filter('fps', fps=30, round='up')
                    .filter('trim', duration=duracion_real_clip)
                    .filter('setpts', 'PTS-STARTPTS')
                )
                clips_ffmpeg.append(nodo_video)

            # 4. Concatenación y Render
            logger.info("Ensamblando la línea de tiempo en FFmpeg...")
            video_unido = ffmpeg.concat(*clips_ffmpeg, v=1, a=0)
            audio_input = ffmpeg.input(ruta_audio).audio

            ruta_salida = os.path.join(self.output_dir, f"video_final_{tema}.mp4")
            
            logger.info("Renderizando... Esto usará tu CPU/GPU a fondo.")
            (
                ffmpeg
                .output(
                    video_unido, 
                    audio_input, 
                    ruta_salida,
                    vcodec='libx264', 
                    acodec='aac', 
                    pix_fmt='yuv420p',
                    preset='fast',
                    loglevel='error'
                )
                .overwrite_output()
                .run(capture_stdout=True, capture_stderr=True)
            )

            logger.info(f"✅ PRODUCCIÓN FINALIZADA: {ruta_salida}")
            return True

        except Exception as e:
            logger.critical(f"Explosión en la producción de vídeo: {e}")
            return False