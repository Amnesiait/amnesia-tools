import os
from datetime import datetime
from config.logger import logger
from api_clients.gemini_client import GeminiClient
from api_clients.youtube_client import YouTubeClient

class CompetitorEngine:
    def __init__(self):
        try:
            self.llm = GeminiClient()
            self.yt_client = YouTubeClient()
        except ValueError:
            logger.error("Faltan credenciales para iniciar CompetitorEngine.")
            raise

        self.output_dir = "output/competencia"
        self._asegurar_directorios()

    def _asegurar_directorios(self):
        try:
            os.makedirs(self.output_dir, exist_ok=True)
        except OSError as e:
            logger.critical(f"Fallo de I/O al crear el directorio de competencia: {e}")
            raise

    def analizar_estrategia(self, info_canal: dict, videos: list) -> str | None:
        logger.info("Enviando datos a Gemini para auditoría de competencia...")

        videos_texto = "\n".join([f"- '{v['titulo']}' | {v['vistas']:,} vistas | {v['likes']:,} likes | {v['fecha']}" for v in videos])

        system_prompt = """Eres un Estratega de YouTube experto en análisis competitivo (Nicho: Tecnología e IA para España).
        Tu misión es destripar la estrategia de un canal rival basándote en sus 10 vídeos más virales.
        
        FORMATO DE RESPUESTA ESTRICTO:
        1. 🕵️‍♂️ PATRONES DE TÍTULOS: [Analiza estructuras, keywords y longitud de los títulos ganadores].
        2. 📈 TEMAS DE ALTO RENDIMIENTO: [Qué tópicos le funcionan mejor y por qué].
        3. 🚀 OPORTUNIDADES PARA NOSOTROS: [Qué brechas deja y cómo podemos robarle audiencia].
        4. 💡 3 IDEAS DE VÍDEOS: [Genera 3 títulos virales para nosotros inspirados en su éxito].
        """

        prompt_usuario = f"""
        CANAL RIVAL: {info_canal['nombre']} (Subs: {info_canal['suscriptores']} | Total Vistas: {info_canal['total_vistas']})
        
        TOP 10 VÍDEOS MÁS VISTOS:
        {videos_texto}
        """

        respuesta = self.llm.generate_text(
            prompt=prompt_usuario,
            system_instruction=system_prompt,
            model='gemini-2.5-pro',
            temperature=0.7
        )
        
        if not respuesta:
            logger.error("Fallo al generar la auditoría de competencia.")
            
        return respuesta

    def auditar_canal(self, entrada: str) -> bool:
        identificador = self.yt_client.extraer_id_canal(entrada)
        if not identificador:
            return False

        info = self.yt_client.buscar_canal(identificador)
        if not info:
            logger.error(f"No se pudo resolver la información para: {entrada}")
            return False

        logger.info(f"Canal detectado: {info['nombre']} ({int(info['suscriptores']):,} subs)")

        videos = self.yt_client.obtener_videos_populares(info["id"])
        if not videos:
            return False

        auditoria = self.analizar_estrategia(info, videos)
        if not auditoria:
            return False

        # Ensamblar reporte
        reporte = [
            f"AUDITORÍA DE COMPETENCIA — {info['nombre']}",
            "="*55,
            f"Suscriptores: {int(info['suscriptores']):,}",
            f"Total de Vídeos: {info['total_videos']}",
            f"Vistas Totales: {int(info['total_vistas']):,}\n",
            "TOP 10 VÍDEOS MÁS VISTOS:"
        ]
        reporte.extend([f"  {i+1:02d}. {v['titulo'][:60]}... — {v['vistas']:,} vistas" for i, v in enumerate(videos)])
        reporte.extend(["\n" + "="*55 + "\n", auditoria])
        
        contenido_final = "\n".join(reporte)

        # Salida por pantalla y disco
        print("\n" + "="*55)
        print(contenido_final)
        print("="*55)

        fecha_str = datetime.now().strftime("%Y%m%d_%H%M")
        nombre_limpio = "".join(c if c.isalnum() else "_" for c in info["nombre"])[:20].lower()
        ruta_salida = os.path.join(self.output_dir, f"auditoria_{nombre_limpio}_{fecha_str}.txt")
        
        try:
            with open(ruta_salida, "w", encoding="utf-8") as f:
                f.write(contenido_final)
            logger.info(f"Auditoría guardada en disco: {ruta_salida}")
            return True
        except IOError as e:
            logger.error(f"Error escribiendo archivo: {e}")
            return False
        
def escanear_nicho_radar(self, nicho: str) -> list[dict]:
        logger.info(f"📡 Iniciando escaneo de Radar para el nicho: {nicho}")
        
        # 1. LA BÚSQUEDA REAL EN YOUTUBE API
        videos_crudos = self.yt_client.buscar_videos_por_nicho(nicho, max_resultados=15)
        
        if not videos_crudos:
            return []

        resultados = []
        for v in videos_crudos:
            vistas = v.get("vistas", 0)
            subs = v.get("subs", 1) 
            
            # 2. EL ALGORITMO: Matemática del Outlier
            ratio_vs = vistas / subs if subs > 0 else 0
            
            if ratio_vs > 50:
                oportunidad = "Extrema"
            elif ratio_vs > 10:
                oportunidad = "Alta"
            elif ratio_vs > 2:
                oportunidad = "Media"
            else:
                oportunidad = "Baja"
                
            # 3. CONTRATO DE DATOS: Empaquetamos para Next.js
            resultados.append({
                "titulo": v.get("titulo", "Sin título"),
                "vistas": vistas,
                "subs": subs,
                "ratio": f"{int(ratio_vs)}x",
                "oportunidad": oportunidad
            })
            
        # Ordenamos de mayor a menor oportunidad
        resultados.sort(key=lambda x: int(x["ratio"].replace("x", "")), reverse=True)
        return resultados