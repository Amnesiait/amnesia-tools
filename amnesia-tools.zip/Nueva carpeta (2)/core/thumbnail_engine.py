import os
from config.logger import logger
from api_clients.gemini_client import GeminiClient
from api_clients.huggingface_client import HuggingFaceClient

class ThumbnailEngine:
    def __init__(self):
        try:
            self.llm = GeminiClient()
            self.hf_client = HuggingFaceClient()
        except ValueError:
            logger.error("Faltan credenciales para el motor de miniaturas.")
            raise

        self.output_dir = "output/thumbnails"
        self._asegurar_directorios()

    def _asegurar_directorios(self):
        try:
            os.makedirs(self.output_dir, exist_ok=True)
        except OSError as e:
            logger.critical(f"Fallo de I/O al crear el directorio de thumbnails: {e}")
            raise

    def generar_prompt_visual(self, titulo: str) -> str | None:
        logger.info(f"Diseñando prompt visual para el título: '{titulo}'")
        
        system_prompt = """Eres un director de arte experto en YouTube. 
        Tu objetivo es crear un prompt de generación de imágenes (en INGLÉS) para Stable Diffusion XL.
        El prompt debe describir una miniatura llamativa, vibrante y de alta calidad sobre tecnología/IA.
        
        REGLAS CRÍTICAS:
        1. SOLO devuelve el prompt en inglés, sin introducciones ni comillas.
        2. Usa descripciones visuales fuertes: highly detailed, cinematic lighting, vibrant colors, 8k resolution, YouTube thumbnail style.
        3. NO pidas que la imagen incluya texto, letras, logos o palabras (la IA no renderiza bien el texto, lo pondremos luego en Canva).
        """
        
        prompt_usuario = f"Crea el prompt visual para un vídeo titulado: '{titulo}'"
        
        prompt_imagen = self.llm.generate_text(
            prompt=prompt_usuario,
            system_instruction=system_prompt,
            model='gemini-2.5-flash',
            temperature=0.7
        )
        
        if prompt_imagen:
            # Limpiamos posibles saltos de línea extra
            prompt_limpio = prompt_imagen.strip().replace("\n", " ")
            logger.info(f"Prompt visual generado: {prompt_limpio}")
            return prompt_limpio
        else:
            logger.error("No se pudo generar el prompt visual.")
            return None

    def generar_y_guardar(self, titulo: str) -> bool:
        # 1. Diseñar el prompt visual
        prompt_visual = self.generar_prompt_visual(titulo)
        if not prompt_visual:
            return False

        # 2. Enviar a Hugging Face
        imagen_bytes = self.hf_client.generate_image(prompt_visual)
        if not imagen_bytes:
            return False

        # 3. Consolidar en disco
        nombre_limpio = "".join(c if c.isalnum() else "_" for c in titulo)[:30].lower()
        from datetime import datetime
        fecha = datetime.now().strftime("%H%M%S")
        ruta_completa = os.path.join(self.output_dir, f"thumb_{nombre_limpio}_{fecha}.jpg")
        
        try:
            with open(ruta_completa, "wb") as file:
                file.write(imagen_bytes)
            logger.info(f"¡Miniatura consolidada en disco!: {ruta_completa}")
            return True
        except IOError as e:
            logger.error(f"Fallo al escribir la imagen en disco: {e}")
            return False