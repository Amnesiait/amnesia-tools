import os
import time
from config.logger import logger

class VoiceRecorder:
    def __init__(self):
        self.output_dir = "voces"
        self.sample_rate = 44100
        self.segundos = 30
        os.makedirs(self.output_dir, exist_ok=True)

    def grabar(self, nombre: str) -> bool:
        try:
            import sounddevice as sd
            from scipy.io.wavfile import write

            ruta = os.path.join(self.output_dir, f"{nombre}.wav")

            logger.info(f"Iniciando grabación de {self.segundos} segundos → {ruta}")
            print(f"\nGuardará en: {ruta}")
            print("Habla con la energía exacta de este registro.")

            for i in range(3, 0, -1):
                print(f"  {i}...")
                time.sleep(1)

            print("🔴 GRABANDO AHORA")
            audio = sd.rec(int(self.segundos * self.sample_rate), samplerate=self.sample_rate, channels=1)
            sd.wait()

            write(ruta, self.sample_rate, audio)
            logger.info(f"Voz grabada con éxito: {ruta}")
            return True

        except Exception as e:
            logger.error(f"Fallo durante la grabación: {e}")
            return False