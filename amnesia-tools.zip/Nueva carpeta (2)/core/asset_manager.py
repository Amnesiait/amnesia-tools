import os
import random
from config.logger import logger

class AssetManager:
    def __init__(self):
        self.base_dir = "biblioteca"
        self.dirs = {
            "videos": os.path.join(self.base_dir, "videos"),
            "musica": os.path.join(self.base_dir, "musica"),
            "sfx": os.path.join(self.base_dir, "sfx")
        }
        self._asegurar_directorios()

    def _asegurar_directorios(self):
        """Crea las carpetas base si no existen."""
        for d in self.dirs.values():
            os.makedirs(d, exist_ok=True)
            
        # Crear subcarpetas de ejemplo para vídeos si está vacío
        for sub_cat in ["tecnologia", "naturaleza", "abstractos"]:
            os.makedirs(os.path.join(self.dirs["videos"], sub_cat), exist_ok=True)

    def obtener_clips_locales(self, categoria: str, cantidad: int = 5) -> list:
        """
        Busca vídeos locales dentro de una categoría específica.
        Si la categoría no existe, busca en toda la carpeta de vídeos.
        """
        ruta_categoria = os.path.join(self.dirs["videos"], categoria.lower())
        ruta_busqueda = ruta_categoria if os.path.exists(ruta_categoria) else self.dirs["videos"]

        archivos_validos = []
        # Buscar en la ruta y en sus subcarpetas
        for root, _, files in os.walk(ruta_busqueda):
            for file in files:
                if file.lower().endswith(('.mp4', '.mov')):
                    archivos_validos.append(os.path.join(root, file))

        if not archivos_validos:
            logger.warning(f"No hay vídeos locales en '{ruta_busqueda}'.")
            return []

        # Devolver una selección aleatoria para que los vídeos no sean siempre iguales
        seleccionados = random.sample(archivos_validos, min(cantidad, len(archivos_validos)))
        logger.info(f"AssetManager extrajo {len(seleccionados)} clips locales de '{categoria}'.")
        return seleccionados

    def obtener_musica_fondo(self) -> str | None:
        """Devuelve una pista de música de fondo aleatoria."""
        ruta_musica = self.dirs["musica"]
        pistas = [f for f in os.listdir(ruta_musica) if f.lower().endswith(('.mp3', '.wav'))]
        
        if pistas:
            pista = random.choice(pistas)
            logger.info(f"Pista de audio local seleccionada: {pista}")
            return os.path.join(ruta_musica, pista)
        
        logger.warning("No se encontró música en la biblioteca local.")
        return None