import os
import time
import requests
from config.logger import logger
from dotenv import load_dotenv

# Cargamos el .env desde la nueva ubicación centralizada
ruta_env = os.path.join(os.path.dirname(__file__), 'config', '.env')
load_dotenv(ruta_env)

class HuggingFaceClient:
    def __init__(self):
        self.api_key = os.getenv("HUGGINGFACE_API_KEY")
        if not self.api_key:
            logger.critical("API Key de Hugging Face no encontrada en el entorno.")
            raise ValueError("Falta HUGGINGFACE_API_KEY en .env")
        
        self.headers = {"Authorization": f"Bearer {self.api_key}"}
        # Usamos Stable Diffusion XL base. Es gratis, rápido y de altísima calidad.
        # Borra la línea anterior de SDXL y pon esta:
        self.model_url = "https://router.huggingface.co/hf-inference/models/black-forest-labs/FLUX.1-schnell"

    def generate_image(self, prompt: str, retries: int = 4) -> bytes | None:
        logger.info("Solicitando generación de imagen a Hugging Face Serverless API...")
        payload = {"inputs": prompt}

        for attempt in range(1, retries + 1):
            try:
                # El timeout es alto porque generar imágenes lleva tiempo
                response = requests.post(self.model_url, headers=self.headers, json=payload, timeout=60)
                
                if response.status_code == 200:
                    logger.info("Imagen generada con éxito por la API de Hugging Face.")
                    return response.content
                
                # Si el modelo está "dormido" y necesita cargarse en sus servidores
                elif response.status_code == 503:
                    espera = 3 ** attempt  # Retroceso exponencial: 3, 9, 27 segundos
                    logger.warning(f"El modelo se está cargando (Error 503). Reintentando en {espera}s... (Intento {attempt}/{retries})")
                    time.sleep(espera)
                    continue
                
                else:
                    logger.error(f"Fallo en la API de Hugging Face. Código {response.status_code}: {response.text}")
                    return None

            except requests.exceptions.Timeout:
                logger.warning(f"Timeout de red. El servidor tardó demasiado. (Intento {attempt}/{retries})")
                time.sleep(5)
            except requests.exceptions.RequestException as e:
                logger.error(f"Error crítico de red al conectar con Hugging Face: {e}")
                return None

        logger.error("Se agotaron los reintentos. No se pudo generar la miniatura. Inténtalo más tarde.")
        return None