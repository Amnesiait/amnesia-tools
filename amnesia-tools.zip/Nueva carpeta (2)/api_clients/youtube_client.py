import os
import logging
import pickle
from dotenv import load_dotenv
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from youtube_transcript_api import YouTubeTranscriptApi
from config.logger import logger
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from googleapiclient.http import MediaFileUpload

# Cargamos el .env desde la nueva ubicación centralizada
ruta_env = os.path.join(os.path.dirname(__file__), 'config', '.env')
load_dotenv(ruta_env)

class YouTubeClient:
    def __init__(self):
        self.api_key = os.getenv("YOUTUBE_API_KEY")
        if not self.api_key:
            logger.critical("API Key de YouTube no encontrada en el entorno.")
            raise ValueError("Falta YOUTUBE_API_KEY en .env")
        
        try:
            # Desactivar logs ruidosos de la librería de Google
            logging.getLogger('googleapiclient.discovery_cache').setLevel(logging.ERROR)
            self.youtube = build('youtube', 'v3', developerKey=self.api_key)
            logger.info("Cliente YouTube Data API instanciado correctamente.")
        except Exception as e:
            logger.critical(f"Fallo crítico al inicializar la API de YouTube: {e}")
            raise

    def obtener_info_video(self, video_id: str) -> dict | None:
        logger.info(f"Solicitando metadatos a YouTube para el vídeo: {video_id}")
        try:
            response = self.youtube.videos().list(
                part='snippet,statistics',
                id=video_id
            ).execute()

            if response.get('items'):
                item = response['items'][0]
                return {
                    'titulo': item['snippet']['title'],
                    'canal': item['snippet']['channelTitle'],
                    'vistas': item['statistics'].get('viewCount', 'N/A'),
                    'likes': item['statistics'].get('likeCount', 'N/A'),
                }
            else:
                logger.warning(f"YouTube no devolvió datos para el ID: {video_id}")
                return None
        except HttpError as e:
            logger.error(f"Error HTTP de la API de YouTube: {e}")
            return None
        except Exception as e:
            logger.error(f"Error no controlado al obtener info del vídeo: {e}")
            return None

    def obtener_transcripcion(self, video_id: str) -> str | None:
        logger.info("Solicitando transcripción del vídeo...")
        # Lista priorizada de idiomas, usando fallback dinámico
        idiomas_prioridad = [['es'], ['es-ES', 'es-MX'], ['es-419'], ['en']]
        
        try:
            # API Moderna (Instanciación + fetch)
            ytt_api = YouTubeTranscriptApi()
            transcript = None
            
            for config_idioma in idiomas_prioridad:
                try:
                    transcript = ytt_api.fetch(video_id, languages=config_idioma)
                    if transcript: break
                except:
                    continue
            
            if not transcript:
                logger.error("No se encontraron subtítulos en español o inglés habilitados por el creador.")
                return None

            texto_completo = []
            for segmento in transcript:
                # La versión moderna devuelve objetos, no diccionarios
                tiempo = int(segmento.start)
                minutos = tiempo // 60
                segundos = tiempo % 60
                texto_completo.append(f"[{minutos:02d}:{segundos:02d}] {segmento.text}")

            logger.info(f"Transcripción obtenida con éxito: {len(transcript)} segmentos.")
            return "\n".join(texto_completo)
            
        except Exception as e:
            logger.error(f"Error nativo al extraer subtítulos: {e}")
            return None
    
    def extraer_id_canal(self, entrada: str) -> str | None:
        import re
        patrones = [r'channel/([UC][a-zA-Z0-9_-]{22})', r'@([\w.-]+)']
        for patron in patrones:
            match = re.search(patron, entrada)
            if match:
                return match.group(1)
        return entrada.strip()

    def buscar_canal(self, entrada: str) -> dict | None:
        logger.info(f"Buscando canal en la API de YouTube: {entrada}")
        try:
            if entrada.startswith("UC") and len(entrada) == 24:
                res = self.youtube.channels().list(part="snippet,statistics", id=entrada).execute()
            else:
                res = self.youtube.search().list(part="snippet", q=entrada, type="channel", maxResults=1).execute()
                if not res.get("items"):
                    return None
                canal_id = res["items"][0]["snippet"]["channelId"]
                res = self.youtube.channels().list(part="snippet,statistics", id=canal_id).execute()

            if res.get("items"):
                item = res["items"][0]
                return {
                    "id": item["id"],
                    "nombre": item["snippet"]["title"],
                    "descripcion": item["snippet"]["description"][:300],
                    "suscriptores": item["statistics"].get("subscriberCount", "N/A"),
                    "total_videos": item["statistics"].get("videoCount", "N/A"),
                    "total_vistas": item["statistics"].get("viewCount", "N/A"),
                }
        except Exception as e:
            logger.error(f"Fallo al buscar canal: {e}")
        return None

    def obtener_videos_populares(self, canal_id: str, max_videos: int = 10) -> list:
        logger.info(f"Extrayendo los {max_videos} vídeos más vistos del canal...")
        try:
            res = self.youtube.search().list(
                part="snippet", channelId=canal_id, order="viewCount", type="video", maxResults=max_videos
            ).execute()
            
            video_ids = [item["id"]["videoId"] for item in res.get("items", [])]
            if not video_ids: return []

            stats = self.youtube.videos().list(part="snippet,statistics", id=",".join(video_ids)).execute()
            videos = []
            for item in stats.get("items", []):
                videos.append({
                    "titulo": item["snippet"]["title"],
                    "vistas": int(item["statistics"].get("viewCount", 0)),
                    "likes": int(item["statistics"].get("likeCount", 0)),
                    "fecha": item["snippet"]["publishedAt"][:10]
                })
            videos.sort(key=lambda x: x["vistas"], reverse=True)
            return videos
        except Exception as e:
            logger.error(f"Fallo al extraer vídeos populares: {e}")
            return []
    
    def autenticar_oauth(self):
        SCOPES = ["https://www.googleapis.com/auth/youtube.upload","https://www.googleapis.com/auth/youtube.readonly"]
        CLIENT_SECRETS = os.path.join("config", "client_secrets.json")
        TOKEN_FILE = "token_youtube.pickle"
        CHANNEL_ID = os.getenv("YOUTUBE_CHANNEL_ID")
        creds = None

        logger.info("Verificando credenciales OAuth2 para subida...")
        
        if not os.path.exists(CLIENT_SECRETS):
            logger.critical(f"Falta el archivo {CLIENT_SECRETS}.")
            return None

        if os.path.exists(TOKEN_FILE):
            with open(TOKEN_FILE, "rb") as token:
                creds = pickle.load(token)

        if not creds or not creds.valid:
            if creds and creds.expired and creds.refresh_token:
                creds.refresh(Request())
            else:
                flow = InstalledAppFlow.from_client_secrets_file(CLIENT_SECRETS, SCOPES)
                creds = flow.run_local_server(port=0)
            with open(TOKEN_FILE, "wb") as token:
                pickle.dump(creds, token)

        youtube_oauth = build("youtube", "v3", credentials=creds)

        if CHANNEL_ID:
            response = youtube_oauth.channels().list(
                part="snippet",
                mine=True
            ).execute()

            canales = response.get("items", [])
            canal_encontrado = next((c for c in canales if c["id"] == CHANNEL_ID), None)

            if canal_encontrado:
                logger.info(f"Canal verificado: {canal_encontrado['snippet']['title']}")
            else:
                logger.warning("El canal del .env no coincide con los canales autenticados.")
                logger.warning("Canales disponibles en esta cuenta:")
                for c in canales:
                    logger.warning(f"  → {c['id']} — {c['snippet']['title']}")
                logger.warning("Borra token_youtube.pickle y vuelve a autenticar.")
                return None

        return youtube_oauth
    def ejecutar_subida(self, cliente_oauth, ruta_video: str, body: dict) -> str | None:
        """Maneja la carga en chunks (pedazos) a los servidores de Google."""
        try:
            logger.info(f"Iniciando subida del archivo: {os.path.basename(ruta_video)}")
            media = MediaFileUpload(
                ruta_video,
                mimetype="video/*",
                resumable=True,
                chunksize=1024 * 1024 * 10  # Chunks de 10MB
            )

            request = cliente_oauth.videos().insert(
                part="snippet,status",
                body=body,
                media_body=media
            )

            response = None
            while response is None:
                status, response = request.next_chunk()
                if status:
                    progreso = int(status.progress() * 100)
                    print(f"\r  Subiendo a YouTube... {progreso}%", end="", flush=True)

            print() # Salto de línea al terminar
            video_id = response["id"]
            logger.info(f"¡Vídeo subido con éxito! ID: {video_id}")
            return video_id

        except Exception as e:
            logger.error(f"Fallo crítico durante la subida a YouTube: {e}")
            return None
        
    def buscar_videos_por_nicho(self, nicho: str, max_resultados: int = 15) -> list:
        """Busca vídeos por palabra clave y obtiene sus vistas y los subs del creador."""
        logger.info(f"Rastreando la API de YouTube para el nicho: {nicho}")
        try:
            # 1. Buscar los vídeos más relevantes para el nicho
            res = self.youtube.search().list(
                part="id,snippet",
                q=nicho,
                type="video",
                order="relevance",
                maxResults=max_resultados
            ).execute()

            video_ids = [item["id"]["videoId"] for item in res.get("items", [])]
            if not video_ids:
                logger.warning("No se encontraron vídeos para este nicho.")
                return []

            # 2. Obtener las vistas de esos vídeos en bloque (ahorra cuota de API)
            stats_videos = self.youtube.videos().list(
                part="snippet,statistics",
                id=",".join(video_ids)
            ).execute()

            videos = []
            channel_ids = set() # Usamos un Set para no repetir canales
            
            for item in stats_videos.get("items", []):
                vistas = int(item["statistics"].get("viewCount", 0))
                # Filtramos shorts o vídeos muy pequeños para limpiar el radar
                if vistas > 10000: 
                    videos.append({
                        "titulo": item["snippet"]["title"],
                        "vistas": vistas,
                        "channel_id": item["snippet"]["channelId"]
                    })
                    channel_ids.add(item["snippet"]["channelId"])

            # 3. Obtener los suscriptores de los dueños de esos vídeos en bloque
            if not channel_ids: return []
            
            stats_canales = self.youtube.channels().list(
                part="statistics",
                id=",".join(list(channel_ids))
            ).execute()

            subs_por_canal = {}
            for c in stats_canales.get("items", []):
                # Usamos un mínimo de 1 sub para evitar divisiones por cero al calcular ratios
                subs_por_canal[c["id"]] = int(c["statistics"].get("subscriberCount", 1))

            # 4. Ensamblar los datos para el motor de competencia
            resultados_finales = []
            for v in videos:
                subs = subs_por_canal.get(v["channel_id"], 1)
                resultados_finales.append({
                    "titulo": v["titulo"],
                    "vistas": v["vistas"],
                    "subs": subs
                })

            return resultados_finales

        except Exception as e:
            logger.error(f"Fallo crítico al escanear vídeos por nicho: {e}")
            return []