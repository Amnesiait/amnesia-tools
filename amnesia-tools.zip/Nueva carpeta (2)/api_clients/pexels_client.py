import os
import requests
from config.logger import logger

class PexelsClient:
    def __init__(self):
        self.pexels_key = os.getenv("PEXELS_API_KEY")
        if not self.pexels_key:
            logger.critical("Falta PEXELS_API_KEY en el archivo .env")
            raise ValueError("Credenciales de Pexels no encontradas.")
        
        self.headers = {"Authorization": self.pexels_key}
        self.search_url = "https://api.pexels.com/videos/search"

    def buscar_clips(self, keyword: str, cantidad: int = 3) -> list:
        """Busca vídeos en Pexels y devuelve una lista con las URLs y metadatos."""
        params = {
            "query": keyword,
            "per_page": cantidad,
            "orientation": "landscape",
            "size": "medium"
        }
        
        try:
            # Añadido timeout estricto de 15 segundos para evitar bloqueos
            response = requests.get(self.search_url, headers=self.headers, params=params, timeout=15)
            response.raise_for_status() # Lanza excepción si el código no es 200 OK
            
            videos = response.json().get("videos", [])
            clips = []
            
            for video in videos:
                for file in video.get("video_files", []):
                    # Buscamos la mejor calidad HD o SD compatible
                    if file.get("quality") in ["hd", "sd"] and file.get("width", 0) >= 1280:
                        clips.append({
                            "url": file["link"],
                            "duration": video.get("duration", 10)
                        })
                        break # Solo cogemos una resolución por vídeo
                        
            logger.info(f"PexelsClient: {len(clips)} clips encontrados para '{keyword}'")
            return clips
            
        except requests.exceptions.RequestException as e:
            logger.error(f"Fallo de red conectando con Pexels API: {e}")
            return []

    def descargar_clip(self, url: str, ruta_salida: str) -> bool:
        """Descarga un clip de vídeo y lo guarda en el disco duro."""
        if os.path.exists(ruta_salida):
            logger.info(f"Clip ya existente en caché temporal: {os.path.basename(ruta_salida)}")
            return True

        try:
            logger.info(f"Descargando nuevo clip de Pexels...")
            response = requests.get(url, stream=True, timeout=30)
            response.raise_for_status()
            
            with open(ruta_salida, "wb") as f:
                for chunk in response.iter_content(chunk_size=1024 * 1024):
                    f.write(chunk)
            return True
            
        except Exception as e:
            logger.error(f"Error crítico en la descarga del archivo: {e}")
            return False