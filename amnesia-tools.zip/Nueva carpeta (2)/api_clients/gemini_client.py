import os
import logging
from google import genai
from google.genai import errors
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type, before_sleep_log
from config.logger import logger

class GeminiClient:
    def __init__(self):
        api_key = os.getenv("GEMINI_API_KEY")
        if not api_key:
            logger.critical("API Key de Gemini no encontrada en el entorno.")
            raise ValueError("Falta GEMINI_API_KEY en .env")
        
        try:
            self.client = genai.Client(api_key=api_key)
            logger.info("Cliente Gemini instanciado correctamente con soporte de reintentos (Tenacity).")
        except Exception as e:
            logger.critical(f"Fallo crítico al inicializar el SDK de Gemini: {e}")
            raise

    # Decorador industrial: Intenta 3 veces. Espera 2s, luego 4s. Solo reintenta en errores de API o red.
    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type((errors.APIError, ConnectionError, TimeoutError)),
        before_sleep=before_sleep_log(logger, logging.WARNING),
        reraise=True
    )
    def generate_text(self, prompt: str, system_instruction: str = None, model: str = 'gemini-2.5-pro', temperature: float = 0.85, response_schema=None) -> str | None:
        logger.info(f"Solicitando generación a Gemini (Modelo: {model})...")
        
        config = {"temperature": temperature}
        if system_instruction:
            config["system_instruction"] = system_instruction
            
        # Activador automático de JSON Estricto
        if response_schema:
            config["response_mime_type"] = "application/json"
            config["response_schema"] = response_schema
            
        try:
            response = self.client.models.generate_content(
                model=model,
                contents=prompt,
                config=config
            )
            
            if response and response.text:
                return response.text
            else:
                logger.warning("Gemini devolvió una respuesta vacía o estructuralmente inválida.")
                return None

        # Excepciones que atrapará Tenacity para reintentar
        except (errors.APIError, ConnectionError, TimeoutError) as e:
            logger.warning(f"Fallo de conexión o API con Gemini: {e}. Tenacity gestionará el reintento...")
            raise  # Lanzamos el error para que Tenacity lo detecte y actúe

        # Excepciones críticas donde NO queremos reintentar (ej. un error de código interno nuestro)
        except Exception as e:
            logger.error(f"Fallo irrecuperable en generate_text: {e}")
            return None