import logging
import sys

def setup_logger(name: str = "AmnesIADivers") -> logging.Logger:
    logger = logging.getLogger(name)
    # Evitar duplicación de handlers si se importa varias veces
    if not logger.handlers:
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter("%(asctime)s - [%(levelname)s] - %(module)s - %(message)s")
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(formatter)
        logger.addHandler(handler)
    return logger

logger = setup_logger()